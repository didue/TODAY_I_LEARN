const $toggleSwitch = document.getElementById('toggleSwitch');

$toggleSwitch.addEventListener('click', ()=> {
  
  //TODO : b-manager onoff하기

});