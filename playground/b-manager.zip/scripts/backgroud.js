/*** 
 * B-Manager 
 * @author didue
 */

let text = 0;
let mediaCnt = {
    img : 0,
    video : 0,

}

chrome.runtime.onInstalled.addListener(()=> {

    
});